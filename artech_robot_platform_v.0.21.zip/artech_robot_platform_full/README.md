# ARTECH Robot Management Platform

Bản web hoàn chỉnh gồm:

- Trang giới thiệu công ty ARTECH dạng web tĩnh.
- Nút Đăng nhập / Đăng ký trên góc trên.
- Đăng ký tài khoản có OTP Gmail, checkbox chấp nhận điều khoản và đồng ý lưu dữ liệu.
- Đăng nhập bằng Email hoặc Tên đăng nhập.
- Quên mật khẩu bằng OTP.
- Dashboard quản lý công ty ARTECH sau khi đăng nhập.
- Quản lý robot, tri thức, album ảnh, dữ liệu học được, tài khoản/thanh toán, hướng dẫn/hỗ trợ.
- Backend API Node.js.
- Database local JSON.
- Mã hóa dữ liệu cá nhân bằng AES-256-GCM.
- Băm mật khẩu bằng PBKDF2-SHA256.
- Login trả token và set HttpOnly Cookie.

## Cách chạy

```bash
npm install
npm start
```

Mở trình duyệt:

```text
http://localhost:3000
```

Tài khoản demo:

```text
Email/Tên đăng nhập: admin
Mật khẩu: Admin@123456
```

## Cấu hình gửi OTP thật qua Gmail

Tạo file `.env` từ file mẫu:

```bash
cp .env.example .env
```

Sửa `.env`:

```env
PORT=3000
APP_SECRET=doi_chuoi_bi_mat_dai_va_kho_doan_de_ma_hoa_du_lieu
SHOW_DEMO_OTP=0

SMTP_HOST=smtp.gmail.com
SMTP_PORT=465
SMTP_SECURE=true
SMTP_USER=your_gmail@gmail.com
SMTP_PASS=your_16_digit_google_app_password
MAIL_FROM="ARTECH Robot <your_gmail@gmail.com>"
```

Lưu ý với Gmail: dùng App Password 16 ký tự, không dùng mật khẩu Gmail chính.

Khi chưa cấu hình SMTP, đặt `SHOW_DEMO_OTP=1` để test local. OTP sẽ hiện trên giao diện và terminal.

## API Backend

### Gửi OTP đăng ký

```http
POST /api/auth/send-otp
Content-Type: application/json
```

```json
{
  "email": "nguyenvana@gmail.com"
}
```

Output:

```json
{
  "success": true,
  "message": "Mã OTP đã được gửi đến Email của bạn",
  "maskedEmail": "ng******@gmail.com"
}
```

### Tạo tài khoản

```http
POST /api/auth/register
Content-Type: application/json
```

Input theo đặc tả, có thể thêm `dob`, `address`, `otp`, `acceptTerms`:

```json
{
  "fullName": "Nguyen Van A",
  "username": "nguyenvana",
  "email": "nguyenvana@gmail.com",
  "phone": "0123456789",
  "dob": "2001-01-01",
  "address": "Ha Noi",
  "password": "123456",
  "confirmPassword": "123456",
  "otp": "123456",
  "acceptTerms": true
}
```

Output thành công:

```json
{
  "success": true,
  "message": "Tạo tài khoản thành công",
  "userId": 1,
  "username": "nguyenvana"
}
```

Output thất bại:

```json
{
  "success": false,
  "message": "Tên đăng nhập hoặc Email đã tồn tại"
}
```

Trong bản này backend sẽ chỉ rõ trường bị trùng, ví dụ:

```json
{
  "success": false,
  "message": "Tên đăng nhập, Email đã tồn tại",
  "fields": ["Tên đăng nhập", "Email"]
}
```

### Đăng nhập

```http
POST /api/auth/login
Content-Type: application/json
```

```json
{
  "email": "user@gmail.com",
  "password": "123456"
}
```

Hoặc:

```json
{
  "username": "admin",
  "password": "Admin@123456"
}
```

Output thành công:

```json
{
  "success": true,
  "token": "tokentaikhoan",
  "role": "Admin"
}
```

Backend cũng set cookie:

```text
Set-Cookie: artech_token=...; HttpOnly; Path=/; SameSite=Lax
```

Output thất bại:

```json
{
  "success": false,
  "message": "Tên đăng nhập hoặc mật khẩu không chính xác"
}
```

### Quên mật khẩu

```http
POST /api/auth/forgot-password
Content-Type: application/json
```

```json
{
  "email": "user@gmail.com"
}
```

Hoặc:

```json
{
  "username": "admin"
}
```

Output thành công:

```json
{
  "success": true,
  "message": "Mã OTP đã được gửi đến Email của bạn"
}
```

Output thất bại:

```json
{
  "success": false,
  "message": "Tài khoản không tồn tại"
}
```

### Đổi mật khẩu bằng OTP

```http
POST /api/auth/reset-password
Content-Type: application/json
```

```json
{
  "email": "user@gmail.com",
  "otp": "123456",
  "password": "newpass123",
  "confirmPassword": "newpass123"
}
```

Output:

```json
{
  "success": true,
  "message": "Đổi mật khẩu thành công"
}
```

## Ghi chú bảo mật

- Không lưu mật khẩu dạng plain text.
- Không lưu trực tiếp email/số điện thoại để so sánh trùng; backend dùng HMAC để tìm kiếm.
- Thông tin cá nhân nằm trong `profileCipher`, đã mã hóa AES-256-GCM.
- `APP_SECRET` phải đổi trước khi dùng thật.
- Trong production nên dùng database thật như MySQL/PostgreSQL thay vì JSON file.

## Cập nhật giao diện 10/06/2026

- Làm mới toàn bộ giao diện theo style ARTECH industrial UI: sidebar trái, nền sáng, card viền mảnh, màu xanh navy, không dùng CDN font để tránh lỗi phông chữ.
- Sửa modal Tài khoản & Đăng nhập:
  - Chỉ còn 2 tab phía trên: **Đăng nhập** và **Tạo tài khoản**.
  - Đã bỏ tab **Quên mật khẩu** ở phía trên.
  - Trong form đăng nhập có 2 nút đặt cạnh nhau: **Tạo tài khoản** và **Quên mật khẩu?**.
  - Form quên mật khẩu vẫn hoạt động qua nút **Quên mật khẩu?**.

## Bản cập nhật giao diện ARTECH

- Web chính chỉ còn thương hiệu ARTECH, không còn nội dung Phenikaa.
- Trang chủ đã bỏ ô OTP xác thực Gmail ở phần thống kê, thay bằng nội dung bảo mật dữ liệu.
- Modal Tài khoản & Đăng nhập đã bỏ tab Tạo tài khoản cạnh tab Đăng nhập; người dùng tạo tài khoản bằng nút dưới form đăng nhập.
- Quản lý Robot có ảnh đại diện từng robot, xem ảnh trong box robot và upload/xóa ảnh robot ở phần Sửa cấu hình.
- Quản lý Tri thức hỗ trợ thêm tài nguyên ảnh: PNG, JPG, JPEG, WEBP, GIF, BMP, SVG, HEIC, HEIF, TIFF bên cạnh PDF/Word/Text.
- Quản lý Ảnh khi bấm vào album sẽ mở trang chi tiết album dạng full page, có nút quay lại, thêm ảnh mới, xóa album, xem/xóa ảnh.
- Cuối trang chủ có thông tin liên hệ: Zalo, Gmail, Facebook, Instagram.

Nếu trình duyệt vẫn hiển thị dữ liệu cũ, hãy chạy trên bản mới và xóa localStorage hoặc dùng tab ẩn danh vì bản này đổi khóa dữ liệu nội bộ sang `artech_dashboard_data_v5`.


## Cấu trúc tách file v.0.18

- `index.html` + `app.js`: trang chủ tĩnh giới thiệu công ty ARTECH Robotics, sản phẩm, dịch vụ, đối tác, tin tức và liên hệ.
- `dashboard.html` + `dashboard.js`: trang đăng nhập/đăng ký/quên mật khẩu và hệ thống quản lý robot sau khi đăng nhập.
- Các API backend trong `server.js` vẫn giữ nguyên, dùng chung cho `dashboard.html`.

Truy cập nhanh:
- Trang chủ: `http://localhost:3000/`
- Hệ thống quản lý robot: `http://localhost:3000/dashboard.html`
