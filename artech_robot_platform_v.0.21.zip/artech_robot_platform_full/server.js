'use strict';

/*
  ARTECH Robot Management Platform
  - Static landing page + dashboard
  - Đăng ký / Đăng nhập / Quên mật khẩu
  - OTP qua Gmail SMTP, có chế độ demo local
  - Mã hóa dữ liệu cá nhân AES-256-GCM
  - Băm mật khẩu PBKDF2-SHA256
  - Session token + HttpOnly Cookie
  - Database local JSON: ./database/users.json
*/

const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

function loadEnvFile() {
  const envPath = path.join(__dirname, '.env');
  if (!fs.existsSync(envPath)) return;
  const rows = fs.readFileSync(envPath, 'utf8').split(/\r?\n/);
  for (const row of rows) {
    const line = row.trim();
    if (!line || line.startsWith('#')) continue;
    const eq = line.indexOf('=');
    if (eq === -1) continue;
    const key = line.slice(0, eq).trim();
    let value = line.slice(eq + 1).trim();
    if ((value.startsWith('"') && value.endsWith('"')) || (value.startsWith("'") && value.endsWith("'"))) {
      value = value.slice(1, -1);
    }
    if (key && process.env[key] === undefined) process.env[key] = value;
  }
}
loadEnvFile();

const ROOT = __dirname;
const PORT = Number(process.env.PORT || 3000);
const APP_SECRET = process.env.APP_SECRET || 'artech-local-dev-secret-change-before-production';
const SHOW_DEMO_OTP = process.env.SHOW_DEMO_OTP !== '0';
const OTP_TTL_MS = 10 * 60 * 1000;
const SESSION_TTL_MS = 7 * 24 * 60 * 60 * 1000;
const DB_DIR = path.join(ROOT, 'database');
const DB_FILE = path.join(DB_DIR, 'users.json');

const SMTP_HOST = process.env.SMTP_HOST || 'smtp.gmail.com';
const SMTP_PORT = Number(process.env.SMTP_PORT || 465);
const SMTP_SECURE = process.env.SMTP_SECURE ? process.env.SMTP_SECURE === 'true' : SMTP_PORT === 465;
const SMTP_USER = process.env.SMTP_USER || '';
const SMTP_PASS = process.env.SMTP_PASS || '';
const MAIL_FROM = process.env.MAIL_FROM || (SMTP_USER ? `ARTECH Robot <${SMTP_USER}>` : 'ARTECH Robot <no-reply@artech.local>');

const MIME_TYPES = {
  '.html': 'text/html; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.js': 'application/javascript; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.gif': 'image/gif',
  '.webp': 'image/webp',
  '.svg': 'image/svg+xml; charset=utf-8',
  '.ico': 'image/x-icon'
};

function ensureDatabase() {
  fs.mkdirSync(DB_DIR, { recursive: true });
  if (!fs.existsSync(DB_FILE)) {
    const db = {
      nextUserId: 1,
      users: [],
      otps: {},
      sessions: {}
    };
    const admin = createUserRecord(db, {
      fullName: 'Admin ARTECH',
      username: 'admin',
      email: 'admin@artech.vn',
      phone: '0900000000',
      dob: '2000-01-01',
      address: 'Hà Nội',
      password: 'Admin@123456',
      role: 'Admin',
      company: 'ARTECH',
      emailVerified: true,
      acceptTerms: true
    });
    db.users.push(admin);
    writeDb(db);
  }
}

function loadDb() {
  ensureDatabase();
  try {
    const raw = fs.readFileSync(DB_FILE, 'utf8');
    const parsed = JSON.parse(raw || '{}');
    return {
      nextUserId: Number(parsed.nextUserId || 1),
      users: Array.isArray(parsed.users) ? parsed.users : [],
      otps: parsed.otps && typeof parsed.otps === 'object' ? parsed.otps : {},
      sessions: parsed.sessions && typeof parsed.sessions === 'object' ? parsed.sessions : {}
    };
  } catch (error) {
    console.error('Không đọc được database:', error);
    return { nextUserId: 1, users: [], otps: {}, sessions: {} };
  }
}

function writeDb(db) {
  fs.mkdirSync(DB_DIR, { recursive: true });
  const temp = `${DB_FILE}.tmp`;
  fs.writeFileSync(temp, JSON.stringify(db, null, 2), 'utf8');
  fs.renameSync(temp, DB_FILE);
}

function normalizeEmail(value) {
  return String(value || '').trim().toLowerCase();
}

function normalizeUsername(value) {
  return String(value || '').trim().toLowerCase();
}

function normalizePhone(value) {
  return String(value || '').replace(/[\s.\-()+]/g, '').trim();
}

function normalizeIdentifier(value) {
  return String(value || '').trim().toLowerCase();
}

function hmac(value) {
  return crypto.createHmac('sha256', APP_SECRET).update(String(value)).digest('hex');
}

function encryptionKey() {
  return crypto.createHash('sha256').update(APP_SECRET).digest();
}

function encryptText(value) {
  const iv = crypto.randomBytes(12);
  const cipher = crypto.createCipheriv('aes-256-gcm', encryptionKey(), iv);
  const encrypted = Buffer.concat([cipher.update(String(value ?? ''), 'utf8'), cipher.final()]);
  const tag = cipher.getAuthTag();
  return `${iv.toString('base64')}:${tag.toString('base64')}:${encrypted.toString('base64')}`;
}

function decryptText(payload) {
  try {
    const [iv64, tag64, data64] = String(payload || '').split(':');
    if (!iv64 || !tag64 || !data64) return '';
    const decipher = crypto.createDecipheriv('aes-256-gcm', encryptionKey(), Buffer.from(iv64, 'base64'));
    decipher.setAuthTag(Buffer.from(tag64, 'base64'));
    return Buffer.concat([decipher.update(Buffer.from(data64, 'base64')), decipher.final()]).toString('utf8');
  } catch {
    return '';
  }
}

function encryptProfile(profile) {
  return encryptText(JSON.stringify(profile));
}

function decryptProfile(user) {
  try {
    return JSON.parse(decryptText(user.profileCipher) || '{}');
  } catch {
    return {};
  }
}

function hashPassword(password) {
  const salt = crypto.randomBytes(16).toString('hex');
  const iterations = 150000;
  const hash = crypto.pbkdf2Sync(String(password), salt, iterations, 32, 'sha256').toString('hex');
  return { salt, hash, iterations, digest: 'sha256' };
}

function verifyPassword(password, passwordData) {
  if (!passwordData || !passwordData.salt || !passwordData.hash) return false;
  const next = crypto.pbkdf2Sync(String(password), passwordData.salt, passwordData.iterations || 150000, 32, passwordData.digest || 'sha256').toString('hex');
  return safeEqual(next, passwordData.hash);
}

function safeEqual(a, b) {
  const ba = Buffer.from(String(a));
  const bb = Buffer.from(String(b));
  if (ba.length !== bb.length) return false;
  return crypto.timingSafeEqual(ba, bb);
}

function createUserRecord(db, input) {
  const now = new Date().toISOString();
  const username = normalizeUsername(input.username);
  const email = normalizeEmail(input.email);
  const phone = normalizePhone(input.phone);
  const userId = Number(db.nextUserId || 1);
  db.nextUserId = userId + 1;
  return {
    userId,
    username,
    usernameHash: hmac(username),
    emailHash: hmac(email),
    phoneHash: hmac(phone),
    profileCipher: encryptProfile({
      fullName: String(input.fullName || '').trim(),
      email,
      phone,
      dob: String(input.dob || '').trim(),
      address: String(input.address || '').trim(),
      role: input.role || 'User',
      company: input.company || 'ARTECH',
      balance: Number(input.balance || 0)
    }),
    password: hashPassword(input.password),
    emailVerified: Boolean(input.emailVerified),
    dataConsent: Boolean(input.acceptTerms),
    status: input.status || 'active',
    createdAt: now,
    updatedAt: now
  };
}

function publicUser(user) {
  const profile = decryptProfile(user);
  return {
    userId: user.userId,
    username: user.username,
    fullName: profile.fullName || '',
    email: profile.email || '',
    phone: profile.phone || '',
    dob: profile.dob || '',
    address: profile.address || '',
    role: profile.role || 'User',
    company: profile.company || 'ARTECH',
    balance: Number(profile.balance || 0),
    emailVerified: Boolean(user.emailVerified),
    status: user.status || 'active',
    createdAt: user.createdAt
  };
}

function findDuplicateFields(db, payload, exceptUserId = null) {
  const usernameHash = hmac(normalizeUsername(payload.username));
  const emailHash = hmac(normalizeEmail(payload.email));
  const phoneHash = hmac(normalizePhone(payload.phone));
  const fields = [];
  for (const user of db.users) {
    if (exceptUserId && Number(user.userId) === Number(exceptUserId)) continue;
    if (payload.username && user.usernameHash === usernameHash && !fields.includes('Tên đăng nhập')) fields.push('Tên đăng nhập');
    if (payload.email && user.emailHash === emailHash && !fields.includes('Email')) fields.push('Email');
    if (payload.phone && user.phoneHash === phoneHash && !fields.includes('Số điện thoại')) fields.push('Số điện thoại');
  }
  return fields;
}

function duplicateMessage(fields) {
  if (!fields.length) return '';
  return `${fields.join(', ')} đã tồn tại`;
}

function validateEmail(email) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(String(email || '').trim());
}

function validateRegister(payload) {
  const required = [
    ['fullName', 'Họ và tên'],
    ['username', 'Tên đăng nhập'],
    ['email', 'Email/Gmail'],
    ['phone', 'Số điện thoại'],
    ['password', 'Mật khẩu'],
    ['confirmPassword', 'Xác thực mật khẩu']
  ];
  for (const [key, label] of required) {
    if (!String(payload[key] || '').trim()) return `${label} không được để trống`;
  }
  if (!validateEmail(payload.email)) return 'Email/Gmail không hợp lệ';
  if (normalizeUsername(payload.username).length < 3) return 'Tên đăng nhập phải có ít nhất 3 ký tự';
  if (normalizePhone(payload.phone).length < 9) return 'Số điện thoại không hợp lệ';
  if (String(payload.password).length < 6) return 'Mật khẩu phải có ít nhất 6 ký tự';
  if (String(payload.password) !== String(payload.confirmPassword)) return 'Mật khẩu xác nhận không khớp';
  if (!payload.acceptTerms) return 'Bạn cần chấp nhận điều khoản và đồng ý lưu dữ liệu khi upload cho robot';
  return '';
}

function maskEmail(email) {
  const [name = '', domain = ''] = String(email || '').split('@');
  if (!domain) return email;
  const head = name.slice(0, 2) || '*';
  return `${head}${'*'.repeat(Math.max(2, name.length - 2))}@${domain}`;
}

function makeOtp() {
  return String(crypto.randomInt(100000, 999999));
}

function storeOtp(db, key, otp, purpose) {
  db.otps[key] = {
    purpose,
    otpHash: hmac(`${purpose}:${key}:${otp}`),
    expiresAt: Date.now() + OTP_TTL_MS,
    attempts: 0,
    createdAt: new Date().toISOString()
  };
}

function verifyOtp(db, key, otp, purpose, shouldDelete = true) {
  const record = db.otps[key];
  if (!record || record.purpose !== purpose) return { ok: false, message: 'Mã OTP không hợp lệ hoặc đã hết hạn' };
  if (Date.now() > Number(record.expiresAt || 0)) {
    delete db.otps[key];
    return { ok: false, message: 'Mã OTP đã hết hạn' };
  }
  record.attempts = Number(record.attempts || 0) + 1;
  if (record.attempts > 5) {
    delete db.otps[key];
    return { ok: false, message: 'Bạn đã nhập sai OTP quá nhiều lần' };
  }
  const expected = hmac(`${purpose}:${key}:${String(otp || '').trim()}`);
  if (!safeEqual(expected, record.otpHash)) return { ok: false, message: 'Mã OTP không chính xác' };
  if (shouldDelete) delete db.otps[key];
  return { ok: true };
}

async function sendOtpEmail(to, otp, purposeLabel) {
  const subject = `[ARTECH Robot] Mã OTP ${purposeLabel}`;
  const text = `Mã OTP của bạn là: ${otp}. Mã có hiệu lực trong 10 phút. Không chia sẻ mã này cho người khác.`;
  const html = `
    <div style="font-family:Arial,sans-serif;max-width:560px;margin:auto;border:1px solid #e5e7eb;border-radius:16px;padding:24px">
      <h2 style="color:#001e40;margin:0 0 12px">ARTECH Robot Management</h2>
      <p>Mã OTP để ${purposeLabel}:</p>
      <div style="font-size:32px;font-weight:800;letter-spacing:8px;background:#edf4ff;color:#001e40;padding:16px 20px;border-radius:12px;text-align:center">${otp}</div>
      <p style="color:#506077">Mã có hiệu lực trong 10 phút. Không chia sẻ mã này cho người khác.</p>
    </div>`;

  const canSendSmtp = Boolean(SMTP_USER && SMTP_PASS);
  if (!canSendSmtp) {
    console.log(`[DEMO OTP] ${to} | ${purposeLabel}: ${otp}`);
    if (SHOW_DEMO_OTP) return { sent: false, demo: true };
    throw new Error('Chưa cấu hình SMTP_USER/SMTP_PASS trong file .env');
  }

  let nodemailer;
  try {
    nodemailer = require('nodemailer');
  } catch (error) {
    console.log(`[DEMO OTP] ${to} | ${purposeLabel}: ${otp}`);
    if (SHOW_DEMO_OTP) return { sent: false, demo: true };
    throw new Error('Chưa cài nodemailer. Hãy chạy: npm install');
  }

  const transporter = nodemailer.createTransport({
    host: SMTP_HOST,
    port: SMTP_PORT,
    secure: SMTP_SECURE,
    auth: { user: SMTP_USER, pass: SMTP_PASS }
  });
  await transporter.sendMail({ from: MAIL_FROM, to, subject, text, html });
  return { sent: true, demo: false };
}

function parseCookies(req) {
  const header = req.headers.cookie || '';
  const out = {};
  header.split(';').forEach(part => {
    const idx = part.indexOf('=');
    if (idx === -1) return;
    const key = part.slice(0, idx).trim();
    const value = decodeURIComponent(part.slice(idx + 1).trim());
    if (key) out[key] = value;
  });
  return out;
}

function getBearerToken(req) {
  const auth = req.headers.authorization || '';
  if (auth.toLowerCase().startsWith('bearer ')) return auth.slice(7).trim();
  return '';
}

function createSession(db, user) {
  const token = crypto.randomBytes(32).toString('hex');
  const tokenHash = hmac(token);
  db.sessions[tokenHash] = {
    userId: user.userId,
    expiresAt: Date.now() + SESSION_TTL_MS,
    createdAt: new Date().toISOString()
  };
  return token;
}

function getSessionUser(req, db) {
  const cookies = parseCookies(req);
  const token = cookies.artech_token || getBearerToken(req);
  if (!token) return null;
  const tokenHash = hmac(token);
  const session = db.sessions[tokenHash];
  if (!session) return null;
  if (Date.now() > Number(session.expiresAt || 0)) {
    delete db.sessions[tokenHash];
    return null;
  }
  return db.users.find(user => Number(user.userId) === Number(session.userId)) || null;
}

function clearExpired(db) {
  const now = Date.now();
  for (const [key, otp] of Object.entries(db.otps)) {
    if (now > Number(otp.expiresAt || 0)) delete db.otps[key];
  }
  for (const [key, session] of Object.entries(db.sessions)) {
    if (now > Number(session.expiresAt || 0)) delete db.sessions[key];
  }
}

function jsonResponse(res, status, data, extraHeaders = {}) {
  const payload = data && typeof data === 'object' ? data : { success: status >= 200 && status < 300, data };
  res.writeHead(status, {
    'Content-Type': 'application/json; charset=utf-8',
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type, Authorization',
    'Access-Control-Allow-Methods': 'GET, POST, PUT, OPTIONS',
    ...extraHeaders
  });
  res.end(JSON.stringify(payload));
}

function readJsonBody(req) {
  return new Promise((resolve, reject) => {
    let body = '';
    req.on('data', chunk => {
      body += chunk;
      if (body.length > 1024 * 1024 * 2) {
        reject(new Error('Payload quá lớn'));
        req.destroy();
      }
    });
    req.on('end', () => {
      if (!body.trim()) return resolve({});
      try { resolve(JSON.parse(body)); }
      catch { reject(new Error('JSON không hợp lệ')); }
    });
    req.on('error', reject);
  });
}

function findUserByIdentifier(db, identifier) {
  const text = normalizeIdentifier(identifier);
  if (!text) return null;
  if (text.includes('@')) {
    const emailHash = hmac(normalizeEmail(text));
    return db.users.find(user => user.emailHash === emailHash) || null;
  }
  const usernameHash = hmac(normalizeUsername(text));
  return db.users.find(user => user.usernameHash === usernameHash) || null;
}

async function handleApi(req, res, pathname) {
  if (req.method === 'OPTIONS') return jsonResponse(res, 200, { success: true });

  let db = loadDb();
  clearExpired(db);
  writeDb(db);

  try {
    if (req.method === 'GET' && pathname === '/api/auth/me') {
      db = loadDb();
      const user = getSessionUser(req, db);
      if (!user) return jsonResponse(res, 401, { success: false, message: 'Chưa đăng nhập' });
      writeDb(db);
      return jsonResponse(res, 200, { success: true, user: publicUser(user) });
    }

    if (req.method === 'POST' && pathname === '/api/auth/send-otp') {
      const body = await readJsonBody(req);
      const email = normalizeEmail(body.email);
      if (!validateEmail(email)) return jsonResponse(res, 400, { success: false, message: 'Email/Gmail không hợp lệ' });
      db = loadDb();
      const exists = db.users.some(user => user.emailHash === hmac(email));
      if (exists) return jsonResponse(res, 409, { success: false, message: 'Email đã tồn tại' });
      const otp = makeOtp();
      const key = `register:${email}`;
      storeOtp(db, key, otp, 'register');
      const mailInfo = await sendOtpEmail(email, otp, 'xác thực Gmail đăng ký tài khoản');
      writeDb(db);
      return jsonResponse(res, 200, {
        success: true,
        message: 'Mã OTP đã được gửi đến Email của bạn',
        maskedEmail: maskEmail(email),
        ...(mailInfo.demo ? { demoOtp: otp } : {})
      });
    }

    if (req.method === 'POST' && pathname === '/api/auth/register') {
      const body = await readJsonBody(req);
      const error = validateRegister(body);
      if (error) return jsonResponse(res, 400, { success: false, message: error });
      db = loadDb();
      const duplicateFields = findDuplicateFields(db, body);
      if (duplicateFields.length) return jsonResponse(res, 409, { success: false, message: duplicateMessage(duplicateFields), fields: duplicateFields });

      const email = normalizeEmail(body.email);
      const otp = String(body.otp || '').trim();
      if (!otp) return jsonResponse(res, 400, { success: false, message: 'Vui lòng nhập mã OTP xác nhận Gmail' });
      const otpResult = verifyOtp(db, `register:${email}`, otp, 'register', true);
      if (!otpResult.ok) {
        writeDb(db);
        return jsonResponse(res, 400, { success: false, message: otpResult.message });
      }

      const user = createUserRecord(db, {
        ...body,
        emailVerified: true,
        role: body.role || 'User',
        company: body.company || 'ARTECH'
      });
      db.users.push(user);
      writeDb(db);
      return jsonResponse(res, 201, {
        success: true,
        message: 'Tạo tài khoản thành công',
        userId: user.userId,
        username: user.username
      });
    }

    if (req.method === 'POST' && pathname === '/api/auth/login') {
      const body = await readJsonBody(req);
      const identifier = body.email || body.username || body.identifier;
      const password = String(body.password || '');
      if (!identifier || !password) return jsonResponse(res, 400, { success: false, message: 'Vui lòng nhập Email/Tên đăng nhập và mật khẩu' });
      db = loadDb();
      const user = findUserByIdentifier(db, identifier);
      if (!user || user.status === 'locked' || !verifyPassword(password, user.password)) {
        return jsonResponse(res, 401, { success: false, message: 'Tên đăng nhập hoặc mật khẩu không chính xác' });
      }
      const token = createSession(db, user);
      writeDb(db);
      const profile = publicUser(user);
      return jsonResponse(res, 200, {
        success: true,
        token,
        role: profile.role || 'User',
        user: profile
      }, {
        'Set-Cookie': `artech_token=${encodeURIComponent(token)}; HttpOnly; Path=/; Max-Age=${Math.floor(SESSION_TTL_MS / 1000)}; SameSite=Lax`
      });
    }

    if (req.method === 'POST' && pathname === '/api/auth/logout') {
      db = loadDb();
      const token = parseCookies(req).artech_token || getBearerToken(req);
      if (token) delete db.sessions[hmac(token)];
      writeDb(db);
      return jsonResponse(res, 200, { success: true, message: 'Đăng xuất thành công' }, {
        'Set-Cookie': 'artech_token=; HttpOnly; Path=/; Max-Age=0; SameSite=Lax'
      });
    }

    if (req.method === 'POST' && pathname === '/api/auth/forgot-password') {
      const body = await readJsonBody(req);
      const identifier = body.email || body.username || body.identifier;
      if (!identifier) return jsonResponse(res, 400, { success: false, message: 'Vui lòng nhập Email hoặc Tên đăng nhập' });
      db = loadDb();
      const user = findUserByIdentifier(db, identifier);
      if (!user) return jsonResponse(res, 404, { success: false, message: 'Tài khoản không tồn tại' });
      if (user.status === 'locked') return jsonResponse(res, 423, { success: false, message: 'Tài khoản bị khóa' });
      const profile = decryptProfile(user);
      const email = normalizeEmail(profile.email);
      const otp = makeOtp();
      const key = `reset:${user.userId}`;
      storeOtp(db, key, otp, 'reset-password');
      const mailInfo = await sendOtpEmail(email, otp, 'khôi phục mật khẩu');
      writeDb(db);
      return jsonResponse(res, 200, {
        success: true,
        message: 'Mã OTP đã được gửi đến Email của bạn',
        maskedEmail: maskEmail(email),
        ...(mailInfo.demo ? { demoOtp: otp } : {})
      });
    }

    if (req.method === 'POST' && pathname === '/api/auth/reset-password') {
      const body = await readJsonBody(req);
      const identifier = body.email || body.username || body.identifier;
      const otp = String(body.otp || '').trim();
      const password = String(body.password || body.newPassword || '');
      const confirmPassword = String(body.confirmPassword || body.confirmNewPassword || '');
      if (!identifier) return jsonResponse(res, 400, { success: false, message: 'Vui lòng nhập Email hoặc Tên đăng nhập' });
      if (!otp) return jsonResponse(res, 400, { success: false, message: 'Vui lòng nhập mã OTP' });
      if (password.length < 6) return jsonResponse(res, 400, { success: false, message: 'Mật khẩu mới phải có ít nhất 6 ký tự' });
      if (password !== confirmPassword) return jsonResponse(res, 400, { success: false, message: 'Mật khẩu xác nhận không khớp' });
      db = loadDb();
      const user = findUserByIdentifier(db, identifier);
      if (!user) return jsonResponse(res, 404, { success: false, message: 'Tài khoản không tồn tại' });
      const otpResult = verifyOtp(db, `reset:${user.userId}`, otp, 'reset-password', true);
      if (!otpResult.ok) {
        writeDb(db);
        return jsonResponse(res, 400, { success: false, message: otpResult.message });
      }
      user.password = hashPassword(password);
      user.updatedAt = new Date().toISOString();
      writeDb(db);
      return jsonResponse(res, 200, { success: true, message: 'Đổi mật khẩu thành công' });
    }

    if (req.method === 'PUT' && pathname === '/api/account/profile') {
      const body = await readJsonBody(req);
      db = loadDb();
      const user = getSessionUser(req, db);
      if (!user) return jsonResponse(res, 401, { success: false, message: 'Chưa đăng nhập' });
      const current = decryptProfile(user);
      const nextProfile = {
        ...current,
        fullName: String(body.fullName ?? current.fullName ?? '').trim(),
        email: normalizeEmail(body.email ?? current.email ?? ''),
        phone: normalizePhone(body.phone ?? current.phone ?? ''),
        dob: String(body.dob ?? current.dob ?? '').trim(),
        address: String(body.address ?? current.address ?? '').trim()
      };
      const duplicates = findDuplicateFields(db, { username: user.username, email: nextProfile.email, phone: nextProfile.phone }, user.userId);
      const realDuplicates = duplicates.filter(field => field !== 'Tên đăng nhập');
      if (realDuplicates.length) return jsonResponse(res, 409, { success: false, message: duplicateMessage(realDuplicates), fields: realDuplicates });
      user.emailHash = hmac(nextProfile.email);
      user.phoneHash = hmac(nextProfile.phone);
      user.profileCipher = encryptProfile(nextProfile);
      user.updatedAt = new Date().toISOString();
      writeDb(db);
      return jsonResponse(res, 200, { success: true, message: 'Cập nhật tài khoản thành công', user: publicUser(user) });
    }

    return jsonResponse(res, 404, { success: false, message: 'API không tồn tại' });
  } catch (error) {
    console.error(error);
    return jsonResponse(res, 500, { success: false, message: error.message || 'Lỗi server' });
  }
}

function serveStatic(req, res, pathname) {
  let filePath = pathname === '/' ? path.join(ROOT, 'index.html') : path.join(ROOT, pathname);
  filePath = path.normalize(filePath);
  if (!filePath.startsWith(ROOT)) {
    res.writeHead(403, { 'Content-Type': 'text/plain; charset=utf-8' });
    return res.end('Forbidden');
  }
  fs.readFile(filePath, (error, data) => {
    if (error) {
      fs.readFile(path.join(ROOT, 'index.html'), (fallbackError, fallbackData) => {
        if (fallbackError) {
          res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' });
          return res.end('Not found');
        }
        res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
        res.end(fallbackData);
      });
      return;
    }
    const ext = path.extname(filePath).toLowerCase();
    res.writeHead(200, { 'Content-Type': MIME_TYPES[ext] || 'application/octet-stream' });
    res.end(data);
  });
}

ensureDatabase();

const server = http.createServer((req, res) => {
  const url = new URL(req.url, `http://${req.headers.host || 'localhost'}`);
  const pathname = decodeURIComponent(url.pathname);
  if (pathname.startsWith('/api/')) return handleApi(req, res, pathname);
  return serveStatic(req, res, pathname);
});

server.listen(PORT, () => {
  console.log(`ARTECH Robot Management đang chạy: http://localhost:${PORT}`);
  if (!SMTP_USER || !SMTP_PASS) {
    console.log('Chưa cấu hình SMTP. OTP sẽ chạy chế độ demo nếu SHOW_DEMO_OTP=1.');
  }
});
