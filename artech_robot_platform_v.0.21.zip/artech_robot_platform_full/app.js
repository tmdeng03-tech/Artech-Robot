/* ARTECH Robotics - Trang chủ tĩnh */
(function () {
  'use strict';

  const app = document.getElementById('app');
  let landingCategory = 'all';
  const icon = {
    robot: '<svg class="nav-icon" viewBox="0 0 24 24"><path d="M7 12h10"/><path d="M9 7h6"/><path d="M6 12v7h12v-7"/><path d="M8 19v2"/><path d="M16 19v2"/><path d="M12 7V3"/><circle cx="12" cy="3" r="1"/><circle cx="9" cy="15" r="1"/><circle cx="15" cy="15" r="1"/></svg>',
    database: '<svg class="nav-icon" viewBox="0 0 24 24"><ellipse cx="12" cy="5" rx="7" ry="3"/><path d="M5 5v6c0 1.7 3.1 3 7 3s7-1.3 7-3V5"/><path d="M5 11v6c0 1.7 3.1 3 7 3s7-1.3 7-3v-6"/></svg>',
    image: '<svg class="nav-icon" viewBox="0 0 24 24"><rect x="3" y="5" width="18" height="14" rx="2"/><circle cx="8.5" cy="10" r="1.5"/><path d="m21 16-5-5L5 19"/></svg>',
    brain: '<svg class="nav-icon" viewBox="0 0 24 24"><path d="M8 8a4 4 0 1 1 8 0"/><path d="M7 12a4 4 0 1 0 4 4"/><path d="M17 12a4 4 0 1 1-4 4"/><path d="M12 8v10"/><path d="M9 13h6"/></svg>',
    card: '<svg class="nav-icon" viewBox="0 0 24 24"><rect x="3" y="6" width="18" height="12" rx="2"/><path d="M3 10h18"/><path d="M7 15h4"/></svg>',
    help: '<svg class="nav-icon" viewBox="0 0 24 24"><path d="M9 9a3 3 0 1 1 5 2.2c-1 .7-2 1.4-2 2.8"/><path d="M12 18h.01"/><rect x="4" y="3" width="16" height="18" rx="2"/></svg>',
    logout: '<svg class="nav-icon" viewBox="0 0 24 24"><path d="M10 17l5-5-5-5"/><path d="M15 12H3"/><path d="M21 19V5"/></svg>',
    search: '<svg class="icon-inline" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/></svg>',
    close: '<svg class="icon-inline" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M6 6l12 12M18 6 6 18"/></svg>',
    plus: '<svg class="icon-inline" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 5v14M5 12h14"/></svg>',
    upload: '<svg class="icon-inline" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 16V4"/><path d="m7 9 5-5 5 5"/><path d="M20 16v3a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1v-3"/></svg>',
    trash: '<svg class="icon-inline" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 6h18"/><path d="M8 6V4h8v2"/><path d="M6 6l1 15h10l1-15"/><path d="M10 11v6M14 11v6"/></svg>',
    save: '<svg class="icon-inline" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M19 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11l5 5v11a2 2 0 0 1-2 2Z"/><path d="M17 21v-8H7v8"/><path d="M7 3v5h8"/></svg>'
  };

  function openAuth(view = 'login') {
    const target = view === 'register' ? './dashboard.html#register' : './dashboard.html#login';
    window.location.href = target;
  }

  function escapeHtml(value) {
    return String(value ?? '')
      .replaceAll('&', '&amp;')
      .replaceAll('<', '&lt;')
      .replaceAll('>', '&gt;')
      .replaceAll('"', '&quot;')
      .replaceAll("'", '&#039;');
  }

  function setMsg(id, message, type = 'info') {
    const el = document.getElementById(id);
    if (!el) return;
    el.innerHTML = `<div class="message-box ${type}">${escapeHtml(message)}</div>`;
  }

  function formData(form) {
    return Object.fromEntries(new FormData(form).entries());
  }

  function landingProductData() {
    return [
      {
        id: 'bellabot-pro',
        name: 'ARTECH BellaBot Pro',
        category: 'Robot phục vụ',
        categoryKey: 'phuc-vu',
        image: productRobotImage('BellaBot Pro', 0),
        short: 'Robot phục vụ cao cấp cho nhà hàng, khách sạn và khu trải nghiệm dịch vụ.',
        detail: 'ARTECH BellaBot Pro là mẫu robot phục vụ được tối ưu cho không gian tiếp khách cao cấp. Robot hỗ trợ di chuyển linh hoạt, hiển thị nội dung thương hiệu, phát thông báo và phối hợp với hệ thống dashboard để theo dõi trạng thái, pin và dữ liệu vận hành theo thời gian thực.',
        specs: ['Điều phối tác vụ phục vụ', 'Màn hình hiển thị thương hiệu', 'Theo dõi pin & trạng thái', 'Quản lý tập trung qua ARTECH Dashboard']
      },
      {
        id: 'service-max',
        name: 'ARTECH Service Max',
        category: 'Robot phục vụ',
        categoryKey: 'phuc-vu',
        image: productRobotImage('Service Max', 1),
        short: 'Robot hỗ trợ phục vụ đa điểm với giao diện thân thiện và quản lý nội dung linh hoạt.',
        detail: 'ARTECH Service Max phù hợp cho nhà hàng, trung tâm hội nghị và showroom trải nghiệm. Robot có thể chạy kịch bản phục vụ, giới thiệu món hoặc sản phẩm, đồng thời ghi nhận dữ liệu tương tác để doanh nghiệp tối ưu quy trình chăm sóc khách hàng.',
        specs: ['Kịch bản AI tùy biến', 'Giao diện thân thiện', 'Quản lý nội dung tập trung', 'Dữ liệu tương tác theo ca vận hành']
      },
      {
        id: 'reception',
        name: 'ARTECH Reception Nova',
        category: 'Robot lễ tân',
        categoryKey: 'le-tan',
        image: productRobotImage('Reception Nova', 2),
        short: 'Robot lễ tân AI chào khách, hướng dẫn thông tin và giới thiệu doanh nghiệp chuyên nghiệp.',
        detail: 'ARTECH Reception Nova được thiết kế cho sảnh doanh nghiệp, trường học, bệnh viện và trung tâm dịch vụ. Robot có thể chào hỏi khách, dẫn hướng, hiển thị nội dung doanh nghiệp và sử dụng kho tri thức để trả lời những câu hỏi thường gặp.',
        specs: ['Lễ tân AI tiếng Việt', 'Dẫn hướng cơ bản', 'Kho tri thức nội bộ', 'Báo cáo tương tác người dùng']
      },
      {
        id: 'kiosk',
        name: 'ARTECH Info Kiosk',
        category: 'Robot lễ tân',
        categoryKey: 'le-tan',
        image: productRobotImage('Info Kiosk', 3),
        short: 'Kiosk AI hỗ trợ tra cứu thông tin, tiếp nhận câu hỏi và trình chiếu nội dung giới thiệu.',
        detail: 'ARTECH Info Kiosk là lựa chọn phù hợp cho triển lãm, văn phòng tiếp khách và khu giới thiệu sản phẩm. Hệ thống tích hợp AI để tra cứu thông tin, trình chiếu tài nguyên ảnh và gửi dữ liệu người dùng quan tâm về dashboard để phân tích.',
        specs: ['Tra cứu thông tin cảm ứng', 'Tích hợp GPT/Gemini', 'Trình chiếu album ảnh', 'Ghi nhận dữ liệu câu hỏi']
      },
      {
        id: 'delivery-pro',
        name: 'ARTECH Delivery Pro',
        category: 'Robot vận chuyển CN',
        categoryKey: 'van-chuyen',
        image: productRobotImage('Delivery Pro', 4),
        short: 'Robot vận chuyển nội bộ cho nhà máy, kho và văn phòng với cơ chế quản lý lộ trình tập trung.',
        detail: 'ARTECH Delivery Pro hỗ trợ vận chuyển vật phẩm nhẹ trong môi trường nội bộ. Dashboard cho phép doanh nghiệp theo dõi Device ID, tình trạng online, lịch sử hoạt động và cấu hình server riêng cho từng robot.',
        specs: ['Quản lý theo Device ID', 'Theo dõi lịch sử hoạt động', 'Lộ trình nội bộ', 'Đồng bộ dữ liệu server']
      },
      {
        id: 'carrier-x',
        name: 'ARTECH Carrier X',
        category: 'Robot vận chuyển CN',
        categoryKey: 'van-chuyen',
        image: productRobotImage('Carrier X', 5),
        short: 'Robot vận chuyển công nghiệp với khả năng làm việc ổn định ở khu vực phân luồng và kho thông minh.',
        detail: 'ARTECH Carrier X được tối ưu cho việc vận chuyển tài liệu, linh kiện và vật tư trong mô hình nhà máy hoặc văn phòng lớn. Hệ thống có thể kết nối với dashboard để quản lý robot, cảnh báo dừng hoạt động và kiểm soát trạng thái pin theo thời gian thực.',
        specs: ['Vận chuyển nội bộ ổn định', 'Theo dõi pin theo thời gian thực', 'Cảnh báo dừng hoạt động', 'Quản lý đa robot']
      },
      {
        id: 'cleaner-s1',
        name: 'ARTECH Cleaner S1',
        category: 'Robot vệ sinh CN',
        categoryKey: 've-sinh',
        image: productRobotImage('Cleaner S1', 0),
        short: 'Robot vệ sinh công nghiệp cho hành lang, sảnh chờ và khu vực công cộng.',
        detail: 'ARTECH Cleaner S1 phù hợp cho trung tâm thương mại, nhà xưởng, văn phòng và khuôn viên lớn. Robot giúp theo dõi trạng thái vận hành, ghi nhận dữ liệu khu vực vệ sinh và kết nối với dashboard để quản trị từ xa.',
        specs: ['Vệ sinh định kỳ', 'Quản lý khu vực làm việc', 'Theo dõi online/offline', 'Báo cáo bảo trì cơ bản']
      },
      {
        id: 'cleaner-vac',
        name: 'ARTECH Vacuum Pro',
        category: 'Robot vệ sinh CN',
        categoryKey: 've-sinh',
        image: productRobotImage('Vacuum Pro', 1),
        short: 'Robot vệ sinh hút bụi và gom rác nhẹ với cơ chế giám sát kết nối và tài nguyên tiêu thụ.',
        detail: 'ARTECH Vacuum Pro phục vụ trong không gian cần làm sạch định kỳ, giúp doanh nghiệp giảm tải công việc lặp lại. Dữ liệu thiết bị, cấu hình vận hành và hình ảnh robot đều được tập trung trong cùng một hệ thống quản lý.',
        specs: ['Hút bụi và gom rác nhẹ', 'Theo dõi tài nguyên', 'Quản lý hình ảnh robot', 'Kết nối dashboard tập trung']
      },
      {
        id: 'camera-kit',
        name: 'ARTECH Vision Kit',
        category: 'Phụ kiện & Phần mềm',
        categoryKey: 'phu-kien',
        image: productRobotImage('Vision Kit', 2),
        short: 'Bộ camera và phần mềm hỗ trợ quản lý hình ảnh, nhận diện tình trạng và đồng bộ dữ liệu.',
        detail: 'ARTECH Vision Kit là gói mở rộng dành cho robot cần nâng cao khả năng thu thập hình ảnh và quản lý dữ liệu trực quan. Bộ giải pháp này tích hợp album ảnh, phân loại tài nguyên hình ảnh và lưu trữ theo từng chủ đề sử dụng.',
        specs: ['Quản lý album ảnh', 'Gắn dữ liệu theo chủ đề', 'Tối ưu dữ liệu trực quan', 'Đồng bộ với dashboard']
      },
      {
        id: 'software-suite',
        name: 'ARTECH Software Suite',
        category: 'Phụ kiện & Phần mềm',
        categoryKey: 'phu-kien',
        image: productRobotImage('Software Suite', 3),
        short: 'Bộ phần mềm quản lý robot, tri thức và dữ liệu học được trên một nền tảng hợp nhất.',
        detail: 'ARTECH Software Suite giúp doanh nghiệp cấu hình robot, nạp tri thức, quản lý tài nguyên hình ảnh, lưu dữ liệu học được và theo dõi tài khoản thanh toán trong một giao diện trực quan, an toàn và dễ sử dụng.',
        specs: ['Dashboard hợp nhất', 'Quản lý tri thức', 'Theo dõi token sử dụng', 'Phân quyền người dùng']
      },
      {
        id: 'edu-bot',
        name: 'ARTECH EduBot',
        category: 'Robot lễ tân',
        categoryKey: 'le-tan',
        image: productRobotImage('EduBot', 4),
        short: 'Robot tương tác cho trung tâm đào tạo, STEM và khu trải nghiệm công nghệ.',
        detail: 'ARTECH EduBot là giải pháp phù hợp cho trường học, trung tâm trải nghiệm và sự kiện công nghệ. Robot giúp thu hút tương tác, hướng dẫn nội dung học tập và trình diễn năng lực AI theo cách gần gũi, sinh động.',
        specs: ['Tương tác STEM', 'Tích hợp nội dung bài học', 'Trình diễn công nghệ', 'Theo dõi dữ liệu người dùng']
      },
      {
        id: 'patrol-bot',
        name: 'ARTECH Patrol Guard',
        category: 'Robot vận chuyển CN',
        categoryKey: 'van-chuyen',
        image: productRobotImage('Patrol Guard', 5),
        short: 'Robot tuần tra và hỗ trợ giám sát cơ sở vật chất với khả năng ghi nhận thông tin hiện trường.',
        detail: 'ARTECH Patrol Guard phù hợp cho nhà máy, kho và khuôn viên lớn cần giám sát thường xuyên. Robot có thể gửi dữ liệu hình ảnh, thông tin trạng thái và các cảnh báo kết nối về dashboard để đội vận hành xử lý nhanh chóng.',
        specs: ['Tuần tra hỗ trợ giám sát', 'Gửi dữ liệu hình ảnh', 'Cảnh báo kết nối', 'Quản lý đa khu vực']
      }
    ];
  }

  function productRobotImage(title, variant = 0) {
    const palettes = [
      ['#e0f2fe', '#003366', '#00a6e5'],
      ['#ecfeff', '#064e7a', '#2dd4bf'],
      ['#f8fafc', '#0f172a', '#38bdf8'],
      ['#eef2ff', '#1e1b4b', '#818cf8'],
      ['#f0fdf4', '#14532d', '#22c55e'],
      ['#fff7ed', '#7c2d12', '#fb923c']
    ];
    const p = palettes[variant % palettes.length];
    const safeTitle = String(title || 'ARTECH Robot').replace(/[<>&]/g, '');
    const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="960" height="640" viewBox="0 0 960 640"><defs><linearGradient id="bg" x1="0" y1="0" x2="1" y2="1"><stop stop-color="${p[0]}"/><stop offset="1" stop-color="#ffffff"/></linearGradient><radialGradient id="glow" cx="70%" cy="20%" r="55%"><stop stop-color="${p[2]}" stop-opacity=".38"/><stop offset="1" stop-color="${p[2]}" stop-opacity="0"/></radialGradient><filter id="shadow" x="-20%" y="-20%" width="140%" height="140%"><feDropShadow dx="0" dy="22" stdDeviation="18" flood-color="#001e40" flood-opacity=".22"/></filter></defs><rect width="960" height="640" fill="url(#bg)"/><rect width="960" height="640" fill="url(#glow)"/><g opacity=".38"><circle cx="128" cy="120" r="72" fill="#fff"/><circle cx="850" cy="528" r="96" fill="#fff"/></g><g filter="url(#shadow)"><rect x="338" y="132" width="284" height="198" rx="62" fill="#fff" stroke="${p[1]}" stroke-width="10"/><rect x="392" y="188" width="176" height="70" rx="35" fill="${p[1]}"/><circle cx="438" cy="223" r="16" fill="#e0f2fe"/><circle cx="522" cy="223" r="16" fill="#e0f2fe"/><path d="M438 278c28 24 58 24 86 0" fill="none" stroke="${p[2]}" stroke-width="14" stroke-linecap="round"/><path d="M480 132V82" stroke="${p[1]}" stroke-width="18" stroke-linecap="round"/><circle cx="480" cy="66" r="24" fill="${p[2]}"/><rect x="288" y="328" width="384" height="190" rx="68" fill="#ffffff" stroke="${p[1]}" stroke-width="10"/><path d="M288 388h-70c-34 0-62 28-62 62v54" stroke="${p[1]}" stroke-width="24" stroke-linecap="round" opacity=".46"/><path d="M672 388h70c34 0 62 28 62 62v54" stroke="${p[1]}" stroke-width="24" stroke-linecap="round" opacity=".46"/><rect x="354" y="374" width="252" height="54" rx="27" fill="${p[0]}"/><path d="M402 518v54M558 518v54" stroke="${p[1]}" stroke-width="22" stroke-linecap="round"/><circle cx="402" cy="590" r="24" fill="${p[2]}"/><circle cx="558" cy="590" r="24" fill="${p[2]}"/></g><text x="54" y="78" font-family="Segoe UI, Arial" font-size="20" font-weight="800" fill="${p[1]}" letter-spacing="4">ARTECH ROBOTICS</text><text x="54" y="576" font-family="Segoe UI, Arial" font-size="44" font-weight="900" fill="${p[1]}">${safeTitle}</text></svg>`;
    return `data:image/svg+xml;charset=UTF-8,${encodeURIComponent(svg)}`;
  }

  function landingProductFilters() {
    const filters = [
      ['all', 'All'],
      ['phuc-vu', 'Robot Phục Vụ'],
      ['le-tan', 'Robot Lễ Tân'],
      ['van-chuyen', 'Robot Vận Chuyển CN'],
      ['ve-sinh', 'Robot Vệ Sinh CN'],
      ['phu-kien', 'Phụ Kiện & Phần Mềm']
    ];
    return filters.map(([key, label], index) => `<button class="product-filter ${index === 0 ? 'active' : ''}" type="button" data-product-filter="${key}">${label}</button>`).join('');
  }

  function setLandingCategory(key = 'all') {
    landingCategory = key;
    const grid = document.getElementById('landingProductGrid');
    if (grid) grid.innerHTML = landingProductCards(key);
    document.querySelectorAll('[data-product-filter]').forEach(item => item.classList.toggle('active', item.dataset.productFilter === key));
    bindLandingEvents();
  }

  function siteAsset(fileName) {
    return `./assets/${fileName}`;
  }

  function landingProductCards(category = 'all') {
    return landingProductData()
      .filter(product => category === 'all' || product.categoryKey === category)
      .map(product => `
        <article class="product-folder-card v14-product-card" data-category="${product.categoryKey}">
          <div class="product-folder-top">
            <div class="folder-tab"></div>
            <div class="folder-body">
              <img src="${product.image}" alt="${escapeHtml(product.name)}" />
              <div class="folder-overlay">
                <span>${escapeHtml(product.category)}</span>
                <h3>${escapeHtml(product.name)}</h3>
                <p>${escapeHtml(product.short)}</p>
                <button class="btn secondary product-more-btn" type="button" data-product-more="${product.id}">Xem chi tiết</button>
              </div>
            </div>
          </div>
        </article>
      `).join('');
  }

  function partnerCaseData() {
    return [
      {
        id: 'robotminh',
        title: 'Robot Mascot cho thương hiệu RoboMinh',
        tag: 'Triển lãm Robot 8/05',
        desc: 'ARTECH Robotics đồng hành cùng RoboMinh trong hoạt động trình diễn robot mascot tại sự kiện công nghệ. Dự án tập trung vào trải nghiệm tương tác trực tiếp, nhận diện thương hiệu tại gian hàng và tạo điểm nhấn truyền thông cho khách tham quan.',
        result: 'Kết quả ghi nhận: tăng khả năng thu hút khách dừng chân tại gian hàng, tạo hình ảnh thương hiệu trẻ trung, công nghệ và dễ ghi nhớ.',
        images: [siteAsset('robominh.jpg'), siteAsset('partnership-signing.jpg')]
      },
      {
        id: 'telemedicine',
        title: 'Robot Telemedicine cho mô hình chăm sóc từ xa',
        tag: 'Giải pháp y tế thông minh',
        desc: 'Dự án mô phỏng robot hỗ trợ tư vấn và kết nối thông tin trong môi trường y tế. Robot được định hướng trở thành điểm tương tác thân thiện, giúp người dùng tiếp cận thông tin nhanh và giảm tải cho bộ phận tiếp nhận.',
        result: 'Giải pháp giúp chuẩn hóa quy trình tư vấn, hỗ trợ điều phối thông tin và tạo trải nghiệm hiện đại tại điểm tiếp xúc khách hàng.',
        images: [siteAsset('partnership-signing.jpg'), siteAsset('robominh.jpg')]
      },
      {
        id: 'hospitality',
        title: 'Robot Hospitality cho khách sạn và sự kiện',
        tag: 'Tối ưu trải nghiệm khách hàng',
        desc: 'ARTECH xây dựng kịch bản robot lễ tân, giới thiệu dịch vụ và hỗ trợ truyền thông thương hiệu cho khách sạn, hội nghị và khu trải nghiệm. Nội dung có thể tùy biến theo từng chiến dịch.',
        result: 'Robot giúp tăng tính chuyên nghiệp tại sảnh đón khách, hỗ trợ truyền tải thông tin nhất quán và tạo điểm check-in nổi bật.',
        images: [siteAsset('robominh.jpg'), siteAsset('partnership-signing.jpg')]
      }
    ];
  }

  function newsData() {
    return [
      {
        id: 'artech-trend',
        title: 'ARTECH Robotics và hướng đi robot mascot AI tại Việt Nam',
        date: '12/06/2026',
        body: `ARTECH Robotics đang theo đuổi hướng phát triển robot mascot AI dành cho doanh nghiệp Việt, tập trung vào khả năng cá nhân hóa hình ảnh thương hiệu và tối ưu trải nghiệm tại các điểm tiếp xúc khách hàng. Thay vì chỉ xem robot là thiết bị trình diễn công nghệ, ARTECH định vị robot như một tài sản truyền thông có thể vận hành lâu dài.

Trong bối cảnh doanh nghiệp ngày càng cần tạo dấu ấn khác biệt tại sự kiện, showroom, trường học và khu dịch vụ, robot mascot AI có thể đảm nhiệm vai trò chào hỏi, giới thiệu sản phẩm, giải đáp câu hỏi thường gặp và thu thập dữ liệu tương tác. Đây là nhóm ứng dụng có tính thực tế cao, phù hợp với đặc thù thị trường Việt Nam.

Điểm mạnh của ARTECH nằm ở việc kết hợp thiết kế mascot, hệ thống AI hội thoại, quản trị nội dung và nền tảng quản lý robot tập trung. Mỗi robot có thể được gắn với kho tri thức riêng, album hình ảnh, kịch bản vận hành và dữ liệu báo cáo để doanh nghiệp liên tục cải thiện chất lượng trải nghiệm.

Trong thời gian tới, ARTECH Robotics sẽ tiếp tục mở rộng các dòng robot phục vụ, robot lễ tân và robot cho thuê sự kiện. Mục tiêu là giúp doanh nghiệp triển khai công nghệ dễ hơn, chi phí phù hợp hơn và có khả năng tùy biến sâu theo bản sắc thương hiệu.`
      },
      {
        id: 'rental-event',
        title: 'Robot cho thuê sự kiện: giải pháp tạo điểm nhấn tại gian hàng',
        date: '05/06/2026',
        body: `Dịch vụ thuê robot đang trở thành lựa chọn phù hợp cho triển lãm, hội nghị và các hoạt động ra mắt sản phẩm. Doanh nghiệp có thể sử dụng robot trong thời gian ngắn để chào khách, dẫn dắt thông tin, trình chiếu nội dung và tạo hiệu ứng truyền thông.

ARTECH Robotics xây dựng gói thuê robot theo hướng trọn gói: chuẩn bị hình ảnh robot, cấu hình nội dung chào hỏi, cài đặt kịch bản giới thiệu và hỗ trợ kỹ thuật trong suốt thời gian sự kiện. Điều này giúp doanh nghiệp không cần đầu tư thiết bị ngay từ đầu nhưng vẫn có trải nghiệm công nghệ chuyên nghiệp.

Robot có thể được cá nhân hóa lời thoại, màn hình hiển thị, nội dung sản phẩm và thông tin thương hiệu. Với mỗi sự kiện, dữ liệu tương tác có thể được ghi nhận để doanh nghiệp hiểu hơn về mối quan tâm của khách tham quan.`
      },
      {
        id: 'mascot-design',
        title: 'Thiết kế mascot thương hiệu kết hợp robot: xu hướng mới cho trải nghiệm khách hàng',
        date: '28/05/2026',
        body: `Mascot thương hiệu từ lâu đã được sử dụng trong truyền thông, nhưng khi kết hợp với robot và AI, mascot không còn chỉ là hình ảnh nhận diện mà trở thành một điểm tương tác sống động. Đây là hướng đi ARTECH Robotics đang tập trung phát triển.

Một robot mascot có thể mang dáng vẻ riêng của thương hiệu, nói bằng giọng điệu phù hợp, trả lời câu hỏi theo bộ tri thức doanh nghiệp và xuất hiện trong các bối cảnh khác nhau như sự kiện, showroom, trường học hoặc khu dịch vụ.

Giá trị lớn nhất nằm ở khả năng tạo cảm xúc và ghi nhớ thương hiệu. Khi khách hàng được tương tác trực tiếp với một đại diện thương hiệu có hình dáng riêng, trải nghiệm sẽ trở nên khác biệt hơn so với màn hình thông tin hoặc booth truyền thống.`
      }
    ];
  }

  function productGallery(product) {
    return [
      product.image,
      siteAsset('robot-red.png'),
      siteAsset('robominh.jpg'),
      siteAsset('partnership-signing.jpg')
    ];
  }

  function productApplications(product) {
    const base = {
      'phuc-vu': ['Nhà hàng, khách sạn, trung tâm hội nghị', 'Khu trải nghiệm dịch vụ cao cấp', 'Sự kiện ra mắt sản phẩm'],
      'le-tan': ['Sảnh doanh nghiệp, showroom, trường học', 'Gian hàng triển lãm và hội chợ', 'Điểm tư vấn thông tin khách hàng'],
      'van-chuyen': ['Nhà máy, kho nội bộ, văn phòng lớn', 'Khu vực cần vận chuyển vật phẩm nhẹ', 'Mô hình điều phối nội bộ thông minh'],
      've-sinh': ['Trung tâm thương mại, sảnh lớn, văn phòng', 'Khu vực công cộng cần vệ sinh định kỳ', 'Nhà xưởng và hành lang vận hành'],
      'phu-kien': ['Nâng cấp robot hiện có', 'Quản lý dữ liệu hình ảnh và tri thức', 'Tích hợp phần mềm vào hệ thống doanh nghiệp']
    };
    return base[product.categoryKey] || ['Sự kiện', 'Showroom', 'Doanh nghiệp'];
  }

  function renderLanding() {
    app.innerHTML = `
      <div class="landing v14-landing">
        <div class="top-strip"></div>
        <header class="landing-nav landing-nav-pro v14-nav">
          <a class="logo v14-logo" href="#home" aria-label="ARTECH Robotics">
            <img src="${siteAsset('artech-logo.png')}" alt="ARTECH Robotics" />
          </a>
          <nav class="nav-center nav-menu-pro" aria-label="Danh mục chính">
            <div class="nav-item has-dropdown"><a href="#about">Về chúng tôi <span class="chev">⌄</span></a><div class="nav-dropdown"><a href="#about">Về ARTECH Robotics</a><a href="#vision">Tầm nhìn - Sứ mệnh</a><a href="#capabilities">Năng lực công ty</a></div></div>
            <div class="nav-item has-dropdown"><a href="#products">Sản phẩm <span class="chev">⌄</span></a><div class="nav-dropdown"><a href="#products" data-product-nav="le-tan">Robot mascot AI</a><a href="#products" data-product-nav="phuc-vu">Robot phục vụ nhà hàng/khách sạn</a><a href="#products" data-product-nav="phu-kien">Trợ lý ảo AI cá nhân hóa</a></div></div>
            <div class="nav-item has-dropdown"><a href="#rent">Thuê Robot <span class="chev">⌄</span></a><div class="nav-dropdown"><a href="#rent">Robot sự kiện</a><a href="#rent">Robot triển lãm</a><a href="#rent">Robot gian hàng</a></div></div>
            <div class="nav-item has-dropdown"><a href="#services">Dịch vụ <span class="chev">⌄</span></a><div class="nav-dropdown"><a href="#services">Thiết kế mascot thương hiệu</a><a href="#services">Bảo hành</a><a href="#services">Bảo trì & nâng cấp</a></div></div>
            <div class="nav-item has-dropdown"><a href="#partner">Đối tác <span class="chev">⌄</span></a><div class="nav-dropdown"><a href="#partner">Khách hàng tiêu biểu</a><a href="#partner">Dự án đã triển khai</a><a href="#partner">Case Study</a></div></div>
            <div class="nav-item has-dropdown"><a href="#news">Tin tức <span class="chev">⌄</span></a><div class="nav-dropdown"><a href="#news">Tin ARTECH Robotics</a><a href="#news">Tuyển dụng</a><a href="#news">Công nghệ robot AI</a></div></div>
            <a class="nav-search" href="#products" aria-label="Tìm kiếm">${icon.search}</a>
          </nav>
          <div class="nav-actions"><button class="btn ghost" data-open-auth="login">Đăng nhập</button><button class="btn primary" data-open-auth="register">Đăng ký</button></div>
        </header>
        <main>
          <section id="home" class="hero hero-pro hero-robot-bg v14-hero">
            <div class="v14-hero-copy reveal-left">
              <div class="eyebrow">ARTECH ROBOTICS</div>
              <h1>Hiện thực hóa bản sắc doanh nghiệp bằng robot AI.</h1>
              <p>ARTECH Robotics phát triển robot mascot AI, robot phục vụ và trợ lý ảo cá nhân hóa cho doanh nghiệp Việt, tập trung vào trải nghiệm thương hiệu, tính tùy biến và hiệu quả vận hành thực tế.</p>
              <p class="hero-note">Chúng tôi kết hợp thiết kế mascot thương hiệu, công nghệ robot, AI hội thoại và nền tảng quản trị nội dung để biến robot thành tài sản chiến lược trong truyền thông, bán hàng và chăm sóc khách hàng.</p>
              <div class="hero-actions"><button class="btn primary explore-products-btn" type="button" data-scroll-products>Khám phá sản phẩm</button><button class="btn secondary" type="button" data-open-auth="login">Truy cập hệ thống</button></div>
            </div>
            <div class="hero-visual reveal-right"><div class="visual-card robot-visual-bg v14-robot-card"><img class="hero-red-robot" src="${siteAsset('robot-red.png')}" alt="Robot ARTECH Robotics" /><div class="float-chip one">Mascot AI</div><div class="float-chip two">Voice · Screen · Data</div><div class="float-chip three">Event Ready</div></div></div>
          </section>

          <section id="about" class="section alt section-bg-robot v14-about-section">
            <div class="about-letter-layout">
              <div class="about-letter reveal-left">
                <div class="eyebrow">Về ARTECH Robotics</div>
                <h2>Tại ARTECH Robotics, chúng tôi dùng công nghệ để hiện thực hóa bản sắc doanh nghiệp.</h2>
                <p><strong>Kính gửi Quý Đối tác,</strong></p>
                <p>Trước hết, thay mặt ARTECH Robotics, tôi xin gửi lời chào trân trọng và lời cảm ơn chân thành đến Quý Đối tác đã quan tâm đến các giải pháp mà chúng tôi đang phát triển.</p>
                <p>Khác biệt lớn nhất của ARTECH Robotics không nằm ở việc chúng tôi làm robot, mà nằm ở cách chúng tôi lựa chọn thị trường và cách chúng tôi tạo ra giá trị. Thay vì cạnh tranh trực diện với các tập đoàn công nghệ lớn trên thế giới, chúng tôi lựa chọn một hướng đi riêng, tập trung vào những thị trường ngách có nhu cầu chuyển đổi cao, nơi các giải pháp đại trà chưa thể đáp ứng hiệu quả.</p>
                <p>ARTECH Robotics theo đuổi chiến lược cá nhân hóa, địa phương hóa và doanh nghiệp hóa, lấy bản sắc riêng của từng thương hiệu, từng tổ chức và văn hóa Việt Nam làm nền tảng phát triển sản phẩm. Nếu các sản phẩm quốc tế có lợi thế về quy mô và tiêu chuẩn hóa, thì chúng tôi tập trung vào sự linh hoạt, tốc độ triển khai, khả năng tùy biến sâu và chi phí phù hợp với doanh nghiệp Việt.</p>
                <p>Chúng tôi cũng là đơn vị tiên phong tại Việt Nam trong việc kết hợp hai yếu tố tưởng chừng tách biệt: Thiết kế mascot thương hiệu và phát triển robot trong cùng một hệ sản phẩm. Chúng tôi tin rằng, trong bối cảnh trải nghiệm khách hàng ngày càng trở thành yếu tố cốt lõi, việc sở hữu một giải pháp vừa mang tính công nghệ, vừa mang tính thương hiệu sẽ giúp doanh nghiệp tạo ra lợi thế cạnh tranh rõ rệt và bền vững.</p>
                <p>ARTECH Robotics mong muốn được đồng hành cùng Quý Đối tác trong hành trình đổi mới và phát triển, thông qua những giải pháp phù hợp, hiệu quả và mang lại giá trị thực tiễn.</p>
                <p><em>Trân trọng,</em></p>
              </div>
              <aside class="director-card reveal-right"><img src="${siteAsset('director-vu-ba-trung.png')}" alt="Chân dung giám đốc công ty ARTECH" /><div><b>Giám đốc công ty ARTECH</b><span>Vũ Bá Trung</span></div></aside>
            </div>
          </section>

          <section id="vision" class="section vision-section">
            <div class="section-head product-head-center">
              <div>
                <div class="eyebrow">Định hướng phát triển</div>
                <h2 class="vision-title">TẦM NHÌN, SỨ MỆNH,<br/>GIÁ TRỊ CỐT LÕI</h2>
                <p class="vision-subtitle">Ba nền tảng định hướng cho chiến lược phát triển, chất lượng triển khai và cam kết đồng hành lâu dài của ARTECH Robotics.</p>
              </div>
            </div>
            <div class="vision-stack">
              <article class="vision-card vision-card-vision reveal-left">
                <div class="vision-card-head"><span>Tầm nhìn</span><i>01</i></div>
                <p>ARTECH Robotics hướng tới vị thế tiên phong tại Việt Nam trong việc ứng dụng robot tích hợp trí tuệ nhân tạo để nâng tầm trải nghiệm thương hiệu và tối ưu vận hành doanh nghiệp. Chúng tôi tạo ra các giải pháp tương tác thông minh, thúc đẩy hiệu quả kinh doanh và đưa bản sắc Việt vươn ra thị trường quốc tế. Trong dài hạn, ARTECH định hình chuẩn mực mới cho việc sử dụng robot trong truyền thông và bán hàng, biến trải nghiệm thương hiệu thành công cụ chiến lược bền vững.</p>
              </article>
              <article class="vision-card vision-card-mission reveal-right">
                <div class="vision-card-head"><span>Sứ mệnh</span><i>02</i></div>
                <p>Sứ mệnh của ARTECH Robotics là kiến tạo những trải nghiệm thương hiệu sống động thông qua robot mascot AI, kết hợp sáng tạo và công nghệ để doanh nghiệp kết nối sâu sắc với khách hàng. Chúng tôi mang đến giải pháp tương tác thông minh, giúp thương hiệu lan tỏa mạnh mẽ tại các sự kiện, gian hàng và điểm tiếp xúc, đồng thời biến robot trở thành tài sản chiến lược, vừa truyền cảm hứng, vừa tạo giá trị lâu dài cho doanh nghiệp.</p>
              </article>
              <article class="vision-card vision-card-values reveal-left">
                <div class="vision-card-head"><span>Giá trị cốt lõi</span><i>03</i></div>
                <ul>
                  <li>Tập trung vào giá trị thực tế</li>
                  <li>Định vị bản sắc thương hiệu</li>
                  <li>Đổi mới công nghệ</li>
                  <li>Lan tỏa và tối ưu trải nghiệm</li>
                  <li>Minh bạch và cam kết chất lượng</li>
                </ul>
              </article>
            </div>
          </section>

          <section id="capabilities" class="section alt section-bg-soft capabilities-section">
            <div class="section-head"><div class="eyebrow">Năng lực công ty</div><h2>Nền tảng năng lực để triển khai robot mascot AI thực tế.</h2></div>
            <div class="capability-grid">
              <article class="capability-card reveal-left"><h3>Nghiên cứu và phát triển sản phẩm</h3><p>ARTECH Robotics tập trung phát triển các giải pháp robot mascot ứng dụng trí tuệ nhân tạo dành cho doanh nghiệp, với khả năng tùy biến linh hoạt theo từng ngành nghề, mục tiêu vận hành và định hướng thương hiệu.</p></article>
              <article class="capability-card reveal-right"><h3>Thiết kế và hiện thực hóa mascot thương hiệu</h3><p>Khác với các giải pháp robot vận hành trên thị trường, ARTECH Robotics có khả năng kết hợp giữa thiết kế mascot độc quyền và công nghệ robot, giúp doanh nghiệp sở hữu những sản phẩm mang dấu ấn thương hiệu riêng, gia tăng khả năng nhận diện và tạo trải nghiệm khác biệt cho khách hàng.</p></article>
              <article class="capability-card reveal-left"><h3>Tích hợp AI và quản trị nội dung</h3><p>Hệ thống được phát triển theo hướng mở, cho phép doanh nghiệp chủ động cập nhật, đào tạo và quản lý nội dung tương tác của robot, tăng tính linh hoạt trong vận hành và giảm sự phụ thuộc vào nhà cung cấp.</p></article>
              <article class="capability-card reveal-right"><h3>Triển khai giải pháp thực tiễn</h3><p>Mỗi giải pháp được thiết kế dựa trên bài toán kinh doanh cụ thể của doanh nghiệp, hướng tới việc nâng cao trải nghiệm khách hàng, gia tăng hiệu quả truyền thông thương hiệu và hỗ trợ tối ưu hoạt động vận hành.</p></article>
              <article class="capability-card wide reveal-left"><h3>Đồng hành dài hạn</h3><p>ARTECH Robotics cung cấp dịch vụ tư vấn, triển khai, bảo trì và nâng cấp xuyên suốt vòng đời sản phẩm, giúp doanh nghiệp khai thác hiệu quả giá trị của robot và công nghệ AI trong dài hạn.</p></article>
            </div>
          </section>

          <section id="products" class="section product-section product-showcase-pro section-bg-soft">
            <div class="section-head product-head product-head-center"><div><div class="eyebrow">Sản phẩm</div><h2 class="product-title-large">CÁC SẢN PHẨM ROBOT ARTECH NỔI BẬT</h2><p class="product-subtitle">Giải pháp tối ưu vận hành và trải nghiệm thương hiệu</p></div></div>
            <div class="product-filter-row">${landingProductFilters()}</div>
            <div class="product-show-grid product-show-grid-cards" id="landingProductGrid">${landingProductCards(landingCategory || 'all')}</div>
          </section>

          <section id="rent" class="section alt rent-section"><div class="section-head"><div class="eyebrow">Thuê Robot</div><h2>ARTECH EventBot – robot cho thuê cho sự kiện, triển lãm và gian hàng.</h2><p class="muted">Dòng robot cho thuê của ARTECH phù hợp với các sự kiện ngắn hạn, hội chợ, showroom, lễ ra mắt sản phẩm và hoạt động truyền thông thương hiệu. Robot có thể chào hỏi, trình chiếu nội dung, trả lời câu hỏi cơ bản và tạo điểm nhấn tương tác tại không gian sự kiện.</p></div><div class="grid-3"><article class="card feature-card"><h3>Sẵn sàng sự kiện</h3><p>Cấu hình nhanh theo nội dung chương trình, thương hiệu và kịch bản tương tác.</p></article><article class="card feature-card"><h3>Hình ảnh nổi bật</h3><p>Robot đỏ ARTECH tạo điểm check-in và tăng khả năng thu hút khách tham quan.</p></article><article class="card feature-card"><h3>Liên hệ báo giá</h3><p>Gói thuê linh hoạt theo ngày, theo tuần hoặc theo chiến dịch truyền thông.</p></article></div></section>

          <section id="services" class="section services-section"><div class="section-head"><div class="eyebrow">Dịch vụ</div><h2>Thiết kế mascot thương hiệu, bảo trì và nâng cấp robot.</h2></div><div class="grid-2"><article class="panel"><h3>Thiết kế Mascot Thương hiệu</h3><p>Tư vấn ý tưởng, thiết kế 2D, thiết kế 3D và chế tác robot theo nhận diện riêng của doanh nghiệp.</p></article><article class="panel"><h3>Bảo trì & Nâng cấp</h3><p>Bảo trì định kỳ, nâng cấp AI, hỗ trợ kỹ thuật, cập nhật nội dung và tối ưu trải nghiệm vận hành dài hạn.</p></article></div></section>

          <section id="partner" class="section alt partner-section"><div class="section-head"><div class="eyebrow">Đối tác</div><h2>Khách hàng tiêu biểu & dự án đã triển khai.</h2><p class="muted">Bấm vào từng khách hàng tiêu biểu để xem mô tả dự án và hình ảnh thực tế.</p></div><div class="partner-layout"><div class="partner-list">${partnerCaseData().map((item, index) => `<button class="partner-card ${index === 0 ? 'active' : ''}" type="button" data-case-id="${item.id}"><b>${escapeHtml(item.title)}</b><span>${escapeHtml(item.tag)}</span></button>`).join('')}</div><div id="partnerCaseBox" class="partner-case-box"></div></div></section>

          <section id="news" class="section news-section"><div class="section-head"><div class="eyebrow">Tin tức</div><h2>Tin tức về ARTECH Robotics.</h2><p class="muted">Bấm vào tin bên cạnh để nội dung chuyển vào khung chính và tự nhảy lên đầu mục tin tức.</p></div><div class="news-layout"><article id="newsMain" class="news-main-scroll"></article><aside class="news-side-list">${newsData().map((item, index) => `<button class="news-side-card ${index === 0 ? 'active' : ''}" type="button" data-news-id="${item.id}"><span>${item.date}</span><b>${escapeHtml(item.title)}</b></button>`).join('')}</aside></div></section>

          ${landingContactSection()}
        </main>
        ${landingFloatingContact()}
      </div><div id="authMount"></div><div id="productMount"></div>`;
    bindLandingEvents();
    renderPartnerCase('robotminh');
    renderNewsArticle(newsData()[0].id);
    bindScrollReveal();
  }

  function landingContactSection() {
    return `
      <section id="contact" class="section contact-section-pro">
        <div class="message-contact-layout"><div class="message-card"><div class="section-head compact-head"><h2>Để lại lời nhắn cho chúng tôi</h2><p>Chúng tôi rất vui khi được lắng nghe ý kiến của bạn.</p></div><form id="contactForm" class="message-form-grid"><div class="field wide"><label>Họ và tên <span class="req">*</span></label><input name="fullName" placeholder="Họ tên của bạn" required /></div><div class="field wide"><label>Số điện thoại <span class="req">*</span></label><input name="phone" placeholder="Nhập số điện thoại" required /></div><div class="field wide"><label>Email</label><input name="email" placeholder="Nhập email của bạn" /></div><div class="field wide"><label>Tên doanh nghiệp <span class="req">*</span></label><input name="company" placeholder="Nhập tên doanh nghiệp của bạn" required /></div><div class="field wide"><label>Địa chỉ (Tỉnh/Thành phố) <span class="req">*</span></label><select name="city" required><option value="">Tìm nhanh tỉnh/thành...</option><option>Hà Nội</option><option>TP. Hồ Chí Minh</option><option>Đà Nẵng</option><option>Hải Phòng</option><option>Bắc Ninh</option></select></div><div class="field wide"><label>Hạng mục bạn quan tâm <span class="req">*</span></label><select name="interest" required><option value="">Chọn hạng mục</option><option>Mua Robot</option><option>Thuê Robot</option><option>Thiết kế mascot thương hiệu</option><option>Bảo trì & nâng cấp</option></select></div><div class="field wide"><label>Nội dung câu hỏi</label><textarea name="message" placeholder="Nhập nội dung ..."></textarea></div><div class="form-actions"><button class="btn contact-submit-btn" type="submit">Gửi thông tin ↗</button></div><div id="contactFormMsg" class="wide"></div></form></div><div class="contact-info-panel"><div class="contact-info-grid-top"><article class="contact-info-box"><div class="contact-info-icon">✉</div><h3>Email</h3><p>Đội ngũ thân thiện của chúng tôi sẽ hỗ trợ bạn</p><a href="mailto:contact@artechrobotics.vn">contact@artechrobotics.vn</a></article><article class="contact-info-box"><div class="contact-info-icon">■</div><h3>Số điện thoại</h3><p>Thứ 2 - thứ 7, 9am - 5pm</p><a href="tel:0981136986">098 113 6986</a></article></div><article class="contact-office-box"><div class="contact-info-icon">⌖</div><h3>Văn phòng</h3><p>Ghé thăm địa chỉ văn phòng của chúng tôi</p><ul><li>CN HN 1: Số 4 Chính Kinh, Thanh Xuân, Hà Nội.</li><li>CN HN 2: Vinacomin Tower, Số 3 Dương Đình Nghệ, Phường Yên Hòa, Hà Nội.</li><li>CN HCM 1: Tòa nhà Dali, 24C Phan Đăng Lưu, Phường Gia Định, TPHCM.</li><li>CN HCM 2: 261 Nguyễn Trãi, Phường Hòa Hưng, Quận 1, TPHCM.</li></ul></article></div></div>
        <div class="footer-links-pro"><div class="footer-brand-col"><img class="footer-logo-img" src="${siteAsset('artech-logo.png')}" alt="ARTECH Robotics" /><p><strong>ARTECH Robotics</strong> | Chuyên cung cấp giải pháp tự động hóa với robot tự hành thông minh.</p><div class="footer-socials"><span>f</span><span>♫</span><span>▶</span></div></div><div><h4>SẢN PHẨM</h4><a href="#products" data-product-nav="le-tan">Robot Mascot AI</a><a href="#products" data-product-nav="phuc-vu">Robot Phục Vụ</a><a href="#products" data-product-nav="phu-kien">Trợ lý ảo AI cá nhân hóa</a></div><div><h4>DỊCH VỤ</h4><a href="#rent">Cho thuê Robot</a><a href="#services">Dịch vụ Thiết kế Mascot</a><a href="#services">Bảo trì & Nâng cấp</a><a href="#services">Hỗ trợ kỹ thuật</a></div><div><h4>HỢP TÁC KINH DOANH</h4><a href="#partner">Chính sách Đại lý</a><a href="#partner">Chính sách Cộng tác viên</a><h4 class="footer-subhead">THÔNG TIN KHÁC</h4><a href="#services">Chính sách bảo hành</a><a href="#services">Giao hàng, lắp đặt</a><a href="#services">Hướng dẫn thay thế vật tư tiêu hao</a></div><div><h4>THÔNG TIN LIÊN HỆ</h4><p>MST công ty: 0318055730</p><p>SĐT: 0981136986</p><p>Email: contact@artechrobotics.vn</p><p>Địa chỉ:</p><ul><li>CN HN 1: Số 4 Chính Kinh, Thanh Xuân, Hà Nội</li><li>CN HN 2: Vinacomin Tower, Số 3 Dương Đình Nghệ, Hà Nội</li><li>CN HCM 1: Tòa nhà Dali, 24C Phan Đăng Lưu, TPHCM</li><li>CN HCM 2: 261 Nguyễn Trãi, Quận 1, TPHCM</li></ul></div></div>
      </section>`;
  }

  function landingFloatingContact() {
    return `<div class="floating-contact" aria-label="Liên hệ nhanh"><a href="#contact" class="float-zalo" aria-label="Liên hệ Zalo"><span class="float-icon zalo-text">Zalo</span></a><a href="#contact" class="float-messenger" aria-label="Liên hệ Messenger"><span class="float-icon messenger-icon"><svg viewBox="0 0 64 64" aria-hidden="true"><defs><linearGradient id="msgGradV14" x1="0" y1="0" x2="1" y2="1"><stop offset="0%" stop-color="#8b5cf6"/><stop offset="100%" stop-color="#ec4899"/></linearGradient></defs><path d="M32 8c-13.3 0-24 9.6-24 21.4 0 6.8 3.5 12.8 9 16.7v9.8l9.2-5.1c1.9.3 3.8.5 5.8.5 13.3 0 24-9.6 24-21.4S45.3 8 32 8Z" fill="url(#msgGradV14)"/><path d="M18 38.2l10-11.3 7.8 6 10.2-11.3-11.2 6.4-7.5-6L18 38.2Z" fill="#fff"/></svg></span></a><a href="#contact" class="float-call" aria-label="Gọi điện"><span class="float-icon call-icon"><svg viewBox="0 0 64 64" aria-hidden="true"><circle cx="32" cy="32" r="30" fill="#003194"/><path d="M41.8 43.7c-1.7 1.7-6.5 1-12.5-4.9-6-6-6.7-10.8-5-12.5l2.9-2.9c.7-.7.8-1.9.2-2.7l-4.5-6.4c-.7-.9-2-1.1-2.9-.3l-3.2 2.8c-3.5 3.1-3.1 9 1 15 3.6 5.4 9 10.8 14.4 14.4 6 4.1 11.9 4.5 15 1l2.8-3.2c.8-.9.7-2.2-.3-2.9l-6.4-4.5c-.8-.6-2-.5-2.7.2l-2.8 2.9Z" fill="#fff"/></svg></span></a></div>`;
  }

  function bindLandingEvents() {
    document.querySelectorAll('[data-open-auth]').forEach(btn => btn.addEventListener('click', () => openAuth(btn.dataset.openAuth || 'login')));
    document.querySelectorAll('[data-product-more]').forEach(btn => btn.addEventListener('click', (event) => { event.stopPropagation(); openProductInfo(btn.dataset.productMore); }));
    document.querySelectorAll('[data-product-filter]').forEach(btn => btn.addEventListener('click', () => setLandingCategory(btn.dataset.productFilter || 'all')));
    document.querySelectorAll('[data-product-nav]').forEach(link => link.addEventListener('click', (event) => { event.preventDefault(); const key = link.dataset.productNav || 'all'; setLandingCategory(key); document.getElementById('products')?.scrollIntoView({ behavior: 'smooth', block: 'start' }); }));
    const explore = document.querySelector('[data-scroll-products]');
    if (explore) explore.addEventListener('click', () => { setLandingCategory('all'); document.getElementById('products')?.scrollIntoView({ behavior: 'smooth', block: 'start' }); });
    const contactForm = document.getElementById('contactForm');
    if (contactForm) contactForm.addEventListener('submit', (event) => { event.preventDefault(); const data = formData(contactForm); setMsg('contactFormMsg', `Cảm ơn ${data.fullName || 'bạn'} đã để lại lời nhắn. Đội ngũ ARTECH sẽ liên hệ trong thời gian sớm nhất.`, 'success'); contactForm.reset(); });
    document.querySelectorAll('[data-case-id]').forEach(btn => btn.addEventListener('click', () => renderPartnerCase(btn.dataset.caseId)));
    document.querySelectorAll('[data-news-id]').forEach(btn => btn.addEventListener('click', () => { renderNewsArticle(btn.dataset.newsId); document.getElementById('news')?.scrollIntoView({ behavior: 'smooth', block: 'start' }); }));
  }

  function renderPartnerCase(caseId) {
    const item = partnerCaseData().find(c => c.id === caseId) || partnerCaseData()[0];
    document.querySelectorAll('[data-case-id]').forEach(btn => btn.classList.toggle('active', btn.dataset.caseId === item.id));
    const box = document.getElementById('partnerCaseBox');
    if (!box) return;
    box.innerHTML = `<div class="partner-case-content"><div><span class="eyebrow">Case Study</span><h3>${escapeHtml(item.title)}</h3><p>${escapeHtml(item.desc)}</p><p><strong>${escapeHtml(item.result)}</strong></p></div><div class="partner-case-images">${item.images.map(src => `<img src="${src}" alt="${escapeHtml(item.title)}" />`).join('')}</div></div>`;
  }

  function renderNewsArticle(newsId) {
    const item = newsData().find(n => n.id === newsId) || newsData()[0];
    document.querySelectorAll('[data-news-id]').forEach(btn => btn.classList.toggle('active', btn.dataset.newsId === item.id));
    const main = document.getElementById('newsMain');
    if (!main) return;
    main.scrollTop = 0;
    main.innerHTML = `<div class="news-main-head"><span>${item.date}</span><h3>${escapeHtml(item.title)}</h3></div>${item.body.split('\n\n').map(p => `<p>${escapeHtml(p)}</p>`).join('')}`;
  }

  function openProductInfo(productId) {
    const product = landingProductData().find(item => item.id === productId);
    if (!product) return;
    const gallery = productGallery(product);
    let index = 0;
    const mount = document.getElementById('productMount');
    mount.innerHTML = `
      <div class="modal-backdrop"><section class="modal product-info-modal v14-product-modal"><div class="modal-head"><div><h2>${escapeHtml(product.name)}</h2><p class="small">${escapeHtml(product.category)} · Giải pháp robot ARTECH</p></div><button class="btn ghost square" data-close-product>${icon.close}</button></div><div class="modal-body"><div class="product-detail-grid"><div class="product-detail-copy"><section><div class="eyebrow">Giới thiệu</div><p>${escapeHtml(product.detail)} Đây là giải pháp được thiết kế để giúp doanh nghiệp nâng cao trải nghiệm khách hàng, tạo điểm nhấn thương hiệu và quản lý nội dung tương tác một cách linh hoạt.</p></section><section><div class="eyebrow">Tính năng</div><ul>${product.specs.concat(['Cá nhân hóa nội dung theo thương hiệu', 'Kết nối dashboard quản lý tập trung', 'Theo dõi dữ liệu tương tác và vận hành']).slice(0, 6).map(item => `<li>${escapeHtml(item)}</li>`).join('')}</ul></section><section><div class="eyebrow">Ứng dụng</div><ul>${productApplications(product).map(item => `<li>${escapeHtml(item)}</li>`).join('')}</ul></section><div class="form-actions"><button class="btn primary" type="button" data-open-auth="login">Vào hệ thống quản lý robot</button></div></div><div class="product-gallery-box"><div class="eyebrow">Hình ảnh thực tế</div><div class="gallery-main"><button class="gallery-arrow left" type="button" data-gallery-prev>&lt;</button><img id="productGalleryMain" src="${gallery[0]}" alt="${escapeHtml(product.name)}" /><button class="gallery-arrow right" type="button" data-gallery-next>&gt;</button></div><div class="gallery-thumbs">${gallery.map((src, i) => `<button type="button" class="gallery-thumb ${i === 0 ? 'active' : ''}" data-gallery-index="${i}"><img src="${src}" alt="Ảnh ${i + 1}" /></button>`).join('')}</div></div></div></div></section></div>`;
    const updateGallery = (nextIndex) => {
      index = (nextIndex + gallery.length) % gallery.length;
      const img = mount.querySelector('#productGalleryMain');
      if (img) img.src = gallery[index];
      mount.querySelectorAll('[data-gallery-index]').forEach(btn => btn.classList.toggle('active', Number(btn.dataset.galleryIndex) === index));
    };
    mount.querySelector('[data-close-product]').addEventListener('click', () => mount.innerHTML = '');
    mount.querySelector('[data-open-auth]').addEventListener('click', () => { mount.innerHTML = ''; openAuth('login'); });
    mount.querySelector('[data-gallery-prev]').addEventListener('click', () => updateGallery(index - 1));
    mount.querySelector('[data-gallery-next]').addEventListener('click', () => updateGallery(index + 1));
    mount.querySelectorAll('[data-gallery-index]').forEach(btn => btn.addEventListener('click', () => updateGallery(Number(btn.dataset.galleryIndex))));
    mount.querySelector('.modal-backdrop').addEventListener('click', (event) => { if (event.target.classList.contains('modal-backdrop')) mount.innerHTML = ''; });
  }

  function bindScrollReveal() {
    const items = document.querySelectorAll('.reveal-left, .reveal-right, .reveal-up');
    if (!items.length) return;
    if (!('IntersectionObserver' in window)) { items.forEach(item => item.classList.add('in-view')); return; }
    const observer = new IntersectionObserver(entries => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.classList.add('in-view');
          observer.unobserve(entry.target);
        }
      });
    }, { threshold: .18 });
    items.forEach(item => observer.observe(item));
  }

  function featureIcon(name) {
    return `<div class="feature-icon">${(icon[name] || icon.robot).replace('nav-icon', 'nav-icon')}</div>`;
  }

  function robotSvg() {
    return `
      <svg class="robot-figure" viewBox="0 0 360 320" fill="none" aria-hidden="true">
        <rect x="108" y="74" width="144" height="116" rx="30" fill="#003366"/>
        <rect x="138" y="104" width="84" height="36" rx="18" fill="#dbeafe"/>
        <circle cx="161" cy="122" r="6" fill="#001e40"/><circle cx="199" cy="122" r="6" fill="#001e40"/>
        <path d="M154 158h52" stroke="#dbeafe" stroke-width="10" stroke-linecap="round"/>
        <path d="M180 74V36" stroke="#003366" stroke-width="14" stroke-linecap="round"/><circle cx="180" cy="30" r="17" fill="#00a6e5"/>
        <path d="M108 130H62c-18 0-32 14-32 32v48" stroke="#8ea4bf" stroke-width="18" stroke-linecap="round"/>
        <path d="M252 130h46c18 0 32 14 32 32v48" stroke="#8ea4bf" stroke-width="18" stroke-linecap="round"/>
        <rect x="84" y="190" width="192" height="72" rx="28" fill="#ffffff" stroke="#cbd5e1" stroke-width="4"/>
        <path d="M136 262v30M224 262v30" stroke="#003366" stroke-width="16" stroke-linecap="round"/>
        <circle cx="136" cy="298" r="14" fill="#00a6e5"/><circle cx="224" cy="298" r="14" fill="#00a6e5"/>
      </svg>`;
  }

  function init() {
    renderLanding();
    bindScrollReveal();
  }

  init();
})();
